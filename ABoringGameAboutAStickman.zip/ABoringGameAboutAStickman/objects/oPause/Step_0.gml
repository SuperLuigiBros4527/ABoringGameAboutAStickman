if (keyboard_check_pressed(vk_escape))
{
    global.paused = !global.paused;
}

if (global.paused)
{
    if (keyboard_check_pressed(vk_space))
    {
        global.paused = false;
    }
    
    if (keyboard_check_pressed(ord("R")))
    {
        global.paused = false;
        room_restart();
    }
    
    if (keyboard_check_pressed(vk_enter))
    {
        global.paused = false;
        game_restart();
    }
}