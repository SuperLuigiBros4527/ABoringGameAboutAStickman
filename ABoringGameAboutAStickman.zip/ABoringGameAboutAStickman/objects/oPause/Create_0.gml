global.paused = false;
display_set_gui_size(364, 205);