if (global.paused)
{
    exit;
}

var _lay_id = layer_get_id("Background");
var _bg_id = layer_background_get_id(_lay_id);
layer_background_htiled(_bg_id, true);
layer_x(_lay_id, layer_get_x(_lay_id) - 0.2);