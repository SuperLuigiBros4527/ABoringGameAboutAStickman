global.paused = false;
var _lay_id = layer_get_id("Background")
var _bg_id = layer_background_get_id(_lay_id);
layer_background_htiled(_bg_id, true);