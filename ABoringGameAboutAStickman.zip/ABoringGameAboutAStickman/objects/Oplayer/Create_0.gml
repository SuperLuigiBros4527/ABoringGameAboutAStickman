window_center()
window_set_size(1092,615)
xsp=0
ysp=0