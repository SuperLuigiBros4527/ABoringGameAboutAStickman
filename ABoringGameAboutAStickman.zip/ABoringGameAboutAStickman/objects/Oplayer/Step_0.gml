if (global.paused)
{
    exit;
}

ysp+=0.1
xsp=0

if (keyboard_check(vk_left) || keyboard_check(ord("A")))
{
    xsp = -1.5
}

if (keyboard_check(vk_right) || keyboard_check(ord("D")))
{
    xsp = 1.5
}

if place_meeting(x, y+1, Oground)
{
    ysp = 0
    if (keyboard_check(vk_up) || keyboard_check(ord("W")))
    {
        ysp = -3
    }
}

if place_meeting(x, y+1, OgroundMiddle)
{
    ysp = 0
    if (keyboard_check(vk_up) || keyboard_check(ord("W")))
    {
        ysp = -3
    }
}

if place_meeting(x, y+1, PancakeBlock)
{
    ysp = 0
    if (keyboard_check(vk_up) || keyboard_check(ord("W")))
    {
        ysp = -3
    }
}

move_and_collide(xsp, ysp, [Oground, OgroundMiddle, PancakeBlock])

if place_meeting(x, y, Ocereal)
{
    if room_exists(room_next(room))
    {
        room_goto_next()
    }
    else
    {
        room_goto(Room1)
    }
}

if place_meeting(x, y, ObutterSpikes)
{
    room_restart()
}

